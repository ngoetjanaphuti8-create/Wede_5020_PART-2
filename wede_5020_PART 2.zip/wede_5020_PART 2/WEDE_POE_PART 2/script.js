// ============================================================
// WILLOW & CRUMBS — PART 2 script.js
// ============================================================

// ---- Cart ----
let cart = [];

function addToCart(name, price) {
  cart.push({ name, price, id: Date.now() });
  renderCart();
  showToast(`${name} added to your order`);
}

function removeFromCart(id) {
  cart = cart.filter(item => item.id !== id);
  renderCart();
}

function renderCart() {
  const container = document.getElementById('cartItems');
  const totalEl   = document.getElementById('cartTotal');
  if (!container) return;

  container.innerHTML = '';

  if (cart.length === 0) {
    container.innerHTML = '<p class="cart-empty">Your cart is empty.<br>Add items from the menu.</p>';
    if (totalEl) totalEl.textContent = 'R0';
    return;
  }

  let total = 0;
  cart.forEach(item => {
    total += item.price;
    const div = document.createElement('div');
    div.className = 'cart-item';
    div.innerHTML = `
      <span>${item.name}</span>
      <span style="display:flex;align-items:center;gap:10px;">
        <strong>R${item.price}</strong>
        <span class="item-remove" onclick="removeFromCart(${item.id})" title="Remove">&times;</span>
      </span>`;
    container.appendChild(div);
  });

  if (totalEl) totalEl.textContent = `R${total}`;
}

function completeOrder() {
  if (cart.length === 0) { showToast('Your cart is empty!'); return; }
  const total = cart.reduce((sum, item) => sum + item.price, 0);
  hideOrderModal();
  setTimeout(() => {
    alert(`Thank you! Your order of R${total} has been received.\nWe'll have it ready shortly.`);
    cart = [];
    renderCart();
  }, 300);
}

// ---- Order Modal ----
function showOrderModal() {
  renderCart();
  document.getElementById('orderModal').classList.add('open');
}
function hideOrderModal() {
  document.getElementById('orderModal').classList.remove('open');
}

// ---- Book Modal ----
function showBookModal() {
  const dateInput = document.getElementById('bookDate');
  if (dateInput) dateInput.value = new Date().toISOString().split('T')[0];
  document.getElementById('bookModal').classList.add('open');
}
function hideBookModal() {
  document.getElementById('bookModal').classList.remove('open');
}

// ---- Booking Submit ----
function handleBookingSubmit(e) {
  e.preventDefault();
  const date   = document.getElementById('bookDate')   ? document.getElementById('bookDate').value   : '';
  const time   = document.getElementById('bookTime')   ? document.getElementById('bookTime').value   : '';
  const guests = document.getElementById('bookGuests') ? document.getElementById('bookGuests').value : '';
  hideBookModal();
  setTimeout(() => {
    alert(`Reservation confirmed!\n\nDate: ${date}\nTime: ${time}\nGuests: ${guests}\n\nSee you soon at Willow & Crumbs!`);
  }, 300);
}

// ---- Contact Submit ----
function handleContactSubmit(e) {
  e.preventDefault();
  showToast('Message sent! We\'ll be in touch soon.');
  e.target.reset();
}

// ---- Menu Tabs ----
function switchTab(tabName) {
  document.querySelectorAll('.menu-category').forEach(el => el.classList.remove('active'));
  document.querySelectorAll('.tab-btn').forEach(el => el.classList.remove('active'));
  const cat = document.getElementById('cat-' + tabName);
  if (cat) cat.classList.add('active');
  document.querySelectorAll(`.tab-btn[data-tab="${tabName}"]`).forEach(el => el.classList.add('active'));
}

// ---- Lightbox ----
function openLightbox(src, caption) {
  const lb  = document.getElementById('lightbox');
  const img = document.getElementById('lightboxImg');
  const cap = document.getElementById('lightboxCaption');
  if (!lb || !img) return;
  img.src = src;
  if (cap) cap.textContent = caption || '';
  lb.classList.add('open');
}
function closeLightbox() {
  const lb = document.getElementById('lightbox');
  if (lb) lb.classList.remove('open');
}

// ---- Hamburger ----
function toggleMenu() {
  const btn  = document.getElementById('hamburger');
  const menu = document.getElementById('mobileMenu');
  if (!btn || !menu) return;
  btn.classList.toggle('open');
  menu.classList.toggle('open');
}

// ---- Toast ----
function showToast(msg) {
  const toast = document.getElementById('toast');
  if (!toast) return;
  toast.textContent = msg;
  toast.classList.add('show');
  setTimeout(() => toast.classList.remove('show'), 3000);
}

// ---- Scroll Reveal ----
function initScrollReveal() {
  const els = document.querySelectorAll('.reveal');
  if (!els.length) return;
  const observer = new IntersectionObserver((entries) => {
    entries.forEach(e => {
      if (e.isIntersecting) {
        e.target.classList.add('visible');
        observer.unobserve(e.target);
      }
    });
  }, { threshold: 0.12 });
  els.forEach(el => observer.observe(el));
}

// ---- Close modals on backdrop click ----
function initBackdropClose() {
  ['orderModal', 'bookModal'].forEach(id => {
    const el = document.getElementById(id);
    if (el) {
      el.addEventListener('click', function(e) {
        if (e.target === this) this.classList.remove('open');
      });
    }
  });
  const lb = document.getElementById('lightbox');
  if (lb) {
    lb.addEventListener('click', function(e) {
      if (e.target === this) closeLightbox();
    });
  }
}

// ---- Close lightbox with Escape key ----
document.addEventListener('keydown', e => {
  if (e.key === 'Escape') {
    closeLightbox();
    hideOrderModal();
    hideBookModal();
  }
});

// ---- Init ----
document.addEventListener('DOMContentLoaded', () => {
  initScrollReveal();
  initBackdropClose();
});
